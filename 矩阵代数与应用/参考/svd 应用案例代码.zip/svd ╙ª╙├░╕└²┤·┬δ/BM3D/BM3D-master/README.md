# BM3D
Matlab implementation of BM3D Algorithm. 

I implemented it just for a simple homework, so it is not complete and could have few errors.

For more information, you can see the following papers:

* [Image Denoising by Sparse 3-D Transform-Domain Collaborative Filtering](https://ieeexplore.ieee.org/stamp/stamp.jsp?arnumber=4271520)

* [An Analysis and Implementation of the BM3D Image Denoising Method](http://www.ipol.im/pub/art/2012/l-bm3d/article.pdf)
