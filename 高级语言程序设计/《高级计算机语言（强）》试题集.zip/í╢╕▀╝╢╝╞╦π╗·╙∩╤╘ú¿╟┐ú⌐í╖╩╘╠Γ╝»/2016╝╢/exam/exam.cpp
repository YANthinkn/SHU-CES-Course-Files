// exam.cpp
#include <iostream>
#include "exam.h"
using namespace std;

int main()
{
//	main02();
//	main0301();
//	main0302();
//	main0303();
//	main0304();
//	main0305();
	main0401();
	main0402();
	main0403();
	return 0;
}
