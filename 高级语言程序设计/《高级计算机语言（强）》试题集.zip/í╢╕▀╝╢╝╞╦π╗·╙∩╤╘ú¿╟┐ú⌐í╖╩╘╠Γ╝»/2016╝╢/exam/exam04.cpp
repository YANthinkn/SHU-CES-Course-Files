// exam04.cpp
#include <iostream>
#include <iomanip>
using namespace std;

void fun(double *x, int n, double &max, double &min, double &aver)
{
	if(n==0) return;
	max = min = aver = x[0];
	for(int i=1; i<n; i++)
	{
		if(x[i]>max) max = x[i];
		if(x[i]<min) min = x[i];
		aver += x[i];
	}
	aver /= n;
}
int main0401()
{
	double max, min, aver;
	double x[] = {	56.8, 98.1, 32.1, 33.6, 42.0,
                   	51.7, 40.2, 54.5, 99.8, 72.5 };
	int n = sizeof(x)/sizeof(*x);    // ��������x��Ԫ�ظ���
	fun(x, n, max, min, aver);
	cout << "n : " << n << ",\tmax : " << max
		  << ",\tmin : " << min << ",\taver : " << aver << endl;
	return 0;
}

int main0402()
{
	char str[100];
	cout << "������һ���ַ�����";
	cin >> str;				// ���� in.getline(str, 80);
	for(int i=0; str[i]!='\0'; i++)
		if(str[i]>='a' && str[i]<='z')
			str[i] -= 'a'-'A';
	cout << str << endl;
	return 0;
}

#include <iostream>
#include <cmath>
using namespace std;

class Point
{
public:
	Point(double x=0, double y=0): x1(x), x2(y)
	{
	}
	friend ostream & operator<<(ostream &out, const Point &p)
	{
		out << "(" << p.x1 << ", " << p.x2 << ")";
		return out;
	}
	double distance(const Point &p)	const
	{
		double dx = x1-p.x1, dy = x2-p.x2;
		return sqrt(dx*dx + dy*dy);
	}
private:
	double x1, x2;
};

int main0403()
{
	Point p0, p1(3), p2(3, 4);

	cout << p0 << '\t' << p1 << '\t' << p2 << endl;
	cout << "d = " << p2.distance(p0) << endl;
	return 0;
}
