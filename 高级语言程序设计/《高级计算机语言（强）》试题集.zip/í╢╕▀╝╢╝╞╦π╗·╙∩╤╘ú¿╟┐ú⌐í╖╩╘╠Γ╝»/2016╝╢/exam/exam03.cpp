// exam03.cpp
#include <iostream>
#include <iomanip>
using namespace std;

int main0301()
{
	cout << "A\n" << char('A'+1)
		 << "\n" << char('8'+1)
		 << "\nOK" << endl;
	return 0;
}

int main0302()
{
	int a = 2, *p = &a;

	cout << "a = " << a << ", *p = " << *p << endl;
	*p = 3;
	cout << "a = " << a << ", *p = " << *p << endl;
	a = 4;
	cout << "a = " << a << ", *p = " << *p << endl;
	p[0] = 5;
	cout << "a = " << a << ", p[0] = " << p[0] << endl;
	return 0;
}

void f()
{
	static int a = 2;
	int b = 6;
	a++;
	b++;
	cout << "in f, a = " << a << ", b = " << b << endl;
}
int main0303()
{
	int a = 10;
	f();
	f();
	cout << "in main, a = " << a << endl;
	return 0;
}

void SetTime(int n, int &hour, int &minute, int &second)
{
	hour = n/3600;
	minute = n/60 % 60;
	second = n % 60;
}
void test(int n)
{
	int hour, minute, second;

	SetTime(n, hour, minute, second);
	cout << setfill('0') << n << "(s) => " << setw(2)
		  << hour << ":" << setw(2) << minute << ":"
		  << setw(2) << second << setfill(' ') << endl;
}
int main0304()
{
	test(59);
	test(60);
	test(123);
	return 0;
}

class A
{
public:
	A(int a=0, int b=0) : x(a), y(b)
	{
		cout << "�������(" << x << ", " << y << ")" << endl;
	}
	~A()
	{
		cout << "�������� ";
		if(x==y)
			cout << "x==y" << endl;
		else
			cout << "x!=y" << endl;
	}
private:
	int x, y;
};
int main0305()
{
	A *p = new A; 
	A x(1, 2), y(3, 3);
	delete p;
	return 0;
}
