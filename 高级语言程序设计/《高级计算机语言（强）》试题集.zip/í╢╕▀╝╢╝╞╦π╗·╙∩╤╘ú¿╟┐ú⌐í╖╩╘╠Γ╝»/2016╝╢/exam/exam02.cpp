#include <iostream>
#include <cstring>
using namespace std;

void SWAP1(int &x, int &y)
{
	int temp = x;
	x = y; y = temp;
}

void SWAP2(double *x, double *y)
{
	double	temp = *x;
	*x = *y; *y = temp;
}

void SWAP3(char *&x, char *&y)
{
	char * temp = x;
	x = y; y = temp;
}

int main02()
{
	int m = 3, n = 5;
	double a = 3.3, b = 5.5;
	char *str1, *str2;
	str1 = new char[80];
	str2 = new char[80];
	strcpy(str1, "Tom");
	strcpy(str2, "Jerry");
	
	SWAP1( m, n );
	cout << "m = " << m << ", n = " << n << endl;

	SWAP2( &a, &b );
	cout << "a = " << a << ", b = " << b << endl;

	SWAP3( str1, str2 );
	cout << "str1: " << str1 << ", str2: " << str2 << endl;
	delete [] str1;
	delete [] str2;
	return 0;
}
