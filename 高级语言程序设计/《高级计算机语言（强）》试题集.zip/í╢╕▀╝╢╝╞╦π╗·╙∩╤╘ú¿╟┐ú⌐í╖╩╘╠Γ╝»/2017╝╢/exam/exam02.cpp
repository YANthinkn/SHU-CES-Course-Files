#include <iostream>
#include <cstring>

using namespace std;

void swap_i(int &a, int &b)			// C++�Ľ������
{
	int temp = a;
	a = b; b = temp;
}

void swap_d(double *a, double *b)	// C���ԵĽ������
{
	double temp = *a;
	*a = *b; *b = temp;
}

void swap_cptr(char *&a, char *&b)	// C++�Ľ������
{
	char *temp = a;
	a = b; b = temp;
}

void swap_c(char **a, char **b)		// C���ԵĽ������
{
	char *temp = *a;
	*a = *b; *b = temp;
}

int main02()
{
	int m = 5, n = 8;
	double a = 5.5, b = 8.8;
	char str1[80] = "Tom", str2[80] = "Jerry";
	char *p, *q;

	swap_i( m, n );
	cout << "m = " << m << ", n = " << n << endl;

	swap_d( &a, &b );
	cout << "a = " << a << ", b = " << b << endl;

	p = str1; q = str2;
	swap_cptr( p, q );
	cout << "p: " << p << ", q: " << q << endl;
	
	p = str1; q = str2;
	swap_c( &p, &q );
	cout << "p: " << p << ", q: " << q << endl;

	return 0;
}
