// exam.h
#ifndef EXAM_H
#define EXAM_H

int main02();
int main0301();
int main0302();
int main0303();
int main0304();
int main0305();
int main0306();
int main0401();
int main0402();
int main0403();

#endif
