// exam.cpp
#include <iostream>
#include "exam.h"
using namespace std;

int main()
{
	int choice=1;
	while(choice)
	{
		cout << "\n��ѡ����ţ�2, 301~306, 401~403��, 0�˳���";
		cin >> choice;
		switch(choice)
		{
		case 2:		main02();	break;
		case 301:	main0301();	break;
		case 302:	main0302();	break;
		case 303:	main0303();	break;
		case 304:	main0304();	break;
		case 305:	main0305();	break;
		case 306:	main0306();	break;
		case 401:	main0401();	break;
		case 402:	main0402();	break;
		case 403:	main0403();	break;
		}
	}
	return 0;
}
