// Student.cpp
#include <iostream>
#include "Student.h"
using namespace std;

Student::Student(int Id)	// ���캯��
{
	id = Id;				// ����ѧ��
	gpa = num = 0;			// ƽ�����㡢ѡ����������0
}

void Student::SetData(int Num, const double *Credit, const double *Score)
{
	num = Num<=N ? Num : N;
	for(int i=0; i<num; i++)
	{
		credit[i] = Credit[i];
		score[i] = Score[i];
	}
}

void Student::Show() const
{
	cout << "ѧ��(" << id << "),\tѡ������(" << num << "),\tƽ������: " << gpa
		 << ",\t(ѧ��, �ɼ�):\t(" << credit[0] << ", " << score[0] << ")";
	for(int i=1; i<num; i++)
		cout << ", (" << credit[i] << ", " << score[i] << ")";
	cout << endl;
}

void Student::GPA()			// ����ɳ�Ա����GPA�Ķ��壬����ƽ������gpa
{
	double sum_credit = 0;
	gpa = 0;
	for(int i=0; i<num; i++)
	{
		sum_credit += credit[i];
		if(score[i] >= 90)
			gpa += credit[i]*4.0;
		else if(score[i] >= 85)
			gpa += credit[i]*3.7;
		else if(score[i]>=82)
			gpa += credit[i]*3.3;
		else if(score[i]>=78)
			gpa += credit[i]*3.0;
		else if(score[i]>=75)
			gpa += credit[i]*2.7;
		else if(score[i]>=72)
			gpa += credit[i]*2.3;
		else if(score[i]>=68)
			gpa += credit[i]*2.0;
		else if(score[i]>=66)
			gpa += credit[i]*1.7;
		else if(score[i]>=64)
			gpa += credit[i]*1.5;
		else if(score[i]>=60)
			gpa += credit[i]*1.0;
	}
	gpa /= sum_credit;
}
