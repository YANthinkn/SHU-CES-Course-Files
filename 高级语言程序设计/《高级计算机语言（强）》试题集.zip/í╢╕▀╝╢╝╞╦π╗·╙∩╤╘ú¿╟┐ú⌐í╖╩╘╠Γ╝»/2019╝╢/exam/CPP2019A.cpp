// CPP2019A.cpp	Ǯΰ��ѧԺ2019-2020�＾ѧ�ڡ��߼����������(ǿ)�����Գ���
#include <iostream>
using namespace std;

int main02();
int main0301(), main0302(), main0303(), main0304(), main0305(), main0306();
int main0401(), main0402(), main0403();

int main()
{
	int choice;
	
	while(true)
	{
		cout << "\n��ѡ�� 2, 301, 302, 303, 304, 305, 306; 401, 402, 403; 0-�˳�: ";
		cin >> choice;
		if(choice<=0)
			break;
		switch(choice)
		{
		case 2:		main02();	break;
		case 301:	main0301();	break;
		case 302:	main0302();	break;
		case 303:	main0303();	break;
		case 304:	main0304();	break;
		case 305:	main0305();	break;
		case 306:	main0306();	break;
		case 401:	main0401();	break;
		case 402:	main0402();	break;
		case 403:	main0403();	break;
		}
	}
	return 0;
}
