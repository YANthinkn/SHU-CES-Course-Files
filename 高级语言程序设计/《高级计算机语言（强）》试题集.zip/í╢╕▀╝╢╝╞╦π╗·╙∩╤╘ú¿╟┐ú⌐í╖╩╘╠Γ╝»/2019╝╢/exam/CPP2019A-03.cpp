// CPP2019A-03.cpp
#include <iostream>
using namespace std;

//////////////////////////
int main0301()
{
	cout << 5%2 << '\n'
		 << 5/2 << '\n'
		 << double(5/2) << '\n'
		 << double(5)/2 << '\n'
		 << 5.0/2 << endl;
	return 0;
}

//////////////////////////
int main0302()
{
	char c = 'A';
	for(int i=0; i<5; i++)
		cout << char(c+i) << endl;
	return 0;
}

//////////////////////////
bool f3(const char *str)
{
	int n=0;
	for(int i=0; str[i]!='\0'; i++)
		if('0'<=str[i] && str[i]<='9')
			n += str[i]-'0';
	return n%3==0;
}

int main0303()
{
	char str[5][80] = {"0", "2", "44", "-3333", "+123123123123123123"};
	for(int i=0; i<5; i++)
		cout << str[i] << (f3(str[i]) ? "" : "��") << "�ܱ�3������" << endl;
	return 0;
}

//////////////////////////
bool f4(int n)
{
	if(n%7==0)
		return true;
	while(n!=0)
	{
		if(n%10==7)
			return true;
		n /= 10;
	}
	return false;
}

int main0304()
{
	for(int n=14; n<=18; n++)
		cout << f4(n) << endl;
	return 0;
}

//////////////////////////
int & Add(int &n)
{
	n++;
	return n;
}
int add(int &n)
{
	int temp = n;
	n++;
	return temp;
}
int main0305()
{
	int n;
	n = 1; cout << ++n << endl;
	n = 1; cout << Add(n) << endl;
	n = 1; cout << Add(Add(n)) << endl;
	n = 1; cout << n++ << endl;
	n = 1; cout << add(n) << endl;
	return 0;
}
//////////////////////////
bool Leapyear(int year)
{
	return year%4==0 && year%100!=0 || year%400==0;
}

int main0306()
{
	int y;
	y = 1900;
	cout << y << "��" << (Leapyear(y)? "":"��") << "������" << endl;
	y = 2000;
	cout << y << "��" << (Leapyear(y)? "":"��") << "������" << endl;
	y = 2018;
	cout << y << "��" << (Leapyear(y)? "":"��") << "������" << endl;
	y = 2019;
	cout << y << "��" << (Leapyear(y)? "":"��") << "������" << endl;
	y = 2020;	cout << y << "��" << (Leapyear(y)? "":"��") << "������" << endl;
	return 0;
}
