// CPP2019A-02.cpp
#include <iostream>
#include <cstring>
using namespace std;

template <typename TYPE> void Swap(TYPE &a, TYPE &b)
{										// ����ģ��
	TYPE temp;
	temp = a;
	a = b;
	b = temp;
}

void Swap(char *str1, char *str2)		// ���غ���ģ��
{
	char *temp = new char[strlen(str1)+1];
	strcpy(temp, str1);
	strcpy(str1, str2);
	strcpy(str2, temp);
	delete [] temp;
}

template <typename TYPE> void Show(const TYPE &a, const TYPE &b)
{
	cout << a << ", " << b << endl;
}

int main02()
{
	char c1='A', c2='B';
	int a=3, b=5;
	double x=3.3, y=5.5;
	char str1[80] = "Tom", str2[80] = "Jerry";
	const char *p1 = "Hello", *p2 = "���";
	
	Swap(c1, c2);		Show(c1, c2);
	Swap(a, b);			Show(a, b);
	Swap(x, y);			Show(x, y);
	Swap(str1, str2);	Show(str1, str2);
	Swap(p1, p2);		Show(p1, p2);
	return 0;
}
